
// --------------------------------navBar--------------------------------

function loginHandler(element) {
    element.innerText = "Logout";
}
// <!-- --------------------------wordBox----------------------------->

function likeHandler(element) {
    console.log("this message is coming from script.js");
}


// ---------------------addButton--------------------
function hide(element) {
    element.remove();
}







