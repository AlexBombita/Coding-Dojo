import logo from './logo.svg';
import './App.css';
import Main from './views/Main';

function App() {
  return (
    <fieldset>
      <legend>App.js</legend>
      <Main />
    </fieldset>
  );
}

export default App;
